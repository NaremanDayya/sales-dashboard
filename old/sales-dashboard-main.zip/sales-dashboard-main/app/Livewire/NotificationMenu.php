<?php

namespace App\Livewire;

use Livewire\Component;

class NotificationMenu extends Component
{
    public function render()
    {
        return view('livewire.notification-menu');
    }
}
