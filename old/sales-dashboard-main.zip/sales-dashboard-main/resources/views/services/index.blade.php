@extends('layouts.master')
@section('title', 'خدمات الشركة')
@section('content')

<div class="min-h-screen bg-gray-50">
    <!-- Header -->
    <header class="bg-white shadow-sm">
        <div class="max-w-7xl mx-auto px-4 py-6 sm:px-6 lg:px-8">
            <div class="flex flex-col md:flex-row md:items-center md:justify-between">
                <div class="flex-1 min-w-0">
                    <h1 class="text-3xl font-bold text-gray-900">خدمات الشركة</h1>
                </div>
                @if (Auth::user()->hasRole('admin'))
                <div class="mt-4 flex md:mt-0 md:ml-4">
                    <a href="{{ route('services.create') }}"
                        class="ml-3 inline-flex items-center px-4 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-indigo-500">
                        <svg class="-ml-1 mr-2 h-5 w-5" xmlns="http://www.w3.org/2000/svg" viewBox="0 0 20 20"
                            fill="currentColor">
                            <path fill-rule="evenodd"
                                d="M10 5a1 1 0 011 1v3h3a1 1 0 110 2h-3v3a1 1 0 11-2 0v-3H6a1 1 0 110-2h3V6a1 1 0 011-1z"
                                clip-rule="evenodd" />
                        </svg>
                    إضافة خدمة جديدة
                    </a>
                </div>
                @endif
            </div>
        </div>
    </header>

    <main class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <!-- Stats -->

        <!-- Services Table -->
        <div class="bg-white shadow overflow-hidden sm:rounded-lg">

            <div class="overflow-x-auto">
                <table class="min-w-full divide-y divide-gray-200">
                    <thead class="bg-gray-50">
                        <tr>
                            <th scope="col"
                                class="px-5 py-3 text-sm font-bold text-black-600 uppercase tracking-wider">
                                نوع الخدمة</th>
                            <th scope="col"
                                class="px-6 py-3 text-center text-sm font-bold  text-black-600 uppercase tracking-wider">
                                التارجت</th>

                @if (Auth::user()->hasRole('admin'))
<th scope="col"
    class="px-6 py-3 text-center text-sm font-bold  text-black-600 uppercase tracking-wider">
نسبة العمولة
</th>
<th scope="col"
    class="px-6 py-3 text-center text-sm font-bold  text-black-600 uppercase tracking-wider">
الإتفاقيات النشطة
</th>
<th scope="col"
    class="px-6 py-3 text-center text-sm font-bold  text-black-600 uppercase tracking-wider">
الإتفاقيات الغير نشطة
</th> 
<th scope="col"
    class="px-6 py-3 text-center text-sm font-bold text-black-600 uppercase tracking-wider">
    الاجراءات
</th>                        


@endif
</tr>
                    </thead>
                    <tbody class="bg-white divide-y divide-gray-200">
                        @foreach ($services as $service)
                        <tr class="hover:bg-gray-50 transition-colors duration-150">
                            <td class="px-6 py-4 whitespace-nowrap">
<div class="flex items-center">
    <div class="flex-shrink-0 h-10 w-10 mr-4">
        <div class="h-full w-full rounded-full bg-indigo-100 flex items-center justify-center">
            <svg class="h-6 w-6 text-indigo-600" xmlns="http://www.w3.org/2000/svg"
                fill="none" viewBox="0 0 24 24" stroke="currentColor">
                <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                    d="M5 12h14M5 12a2 2 0 01-2-2V6a2 2 0 012-2h14a2 2 0 012 2v4a2 2 0 01-2 2M5 12a2 2 0 00-2 2v4a2 2 0 002 2h14a2 2 0 002-2v-4a2 2 0 00-2-2m-2-4h.01M17 16h.01">
                </path>
            </svg>
        </div>
    </div>
    <div class="text-sm font-bold text-gray-900 mr-4">
        {{ $service->name }}
    </div>
</div>
                            </td>
                            <td class="px-6 py-4 whitespace-nowrap">
                                <div class="text-sm text-gray-900">
                                    {{ $service->is_flat_price
                                    ? number_format($service->target_amount) . ' ' . config('app.currency')
                                    : number_format($service->target_amount) }}
                                </div>
                            </td>
                @if (Auth::user()->hasRole('admin'))
<td class="px-6 py-4 text-center whitespace-nowrap">
    {{ rtrim(rtrim(number_format($service->commission_rate, 2, '.', ''), '0'), '.') }}

</td>
<td class="px-6 py-4 text-center whitespace-nowrap">
{{$service->active_agreements_count}}
</td>

<td class="px-6 py-4 text-center whitespace-nowrap">
{{$service->inactive_agreements_count}}
</td>

<td class="px-6 py-4 text-center whitespace-nowrap flex justify-center space-x-2">

    <!-- Edit Button -->
    <a href="{{ route('services.edit', $service->id) }}"
       class="inline-flex items-center px-3 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 focus:outline-none focus:ring-2 focus:ring-indigo-500">
        <svg class="mr-1 h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
            <path stroke-linecap="round" stroke-linejoin="round" d="M15.232 5.232l3.536 3.536M9 11l6 6m-3-6v6m0-6h6" />
        </svg>
        تعديل
    </a>

    <!-- Delete Button (with form) -->
    <form action="{{ route('services.destroy', $service->id) }}" method="POST" onsubmit="return confirm('هل أنت متأكد من حذف هذه الخدمة؟');">
        @csrf
        @method('DELETE')
        <button type="submit"
            class="inline-flex items-center px-3 py-2 border border-transparent rounded-md shadow-sm text-sm font-medium text-white bg-red-600 hover:bg-red-700 focus:outline-none focus:ring-2 focus:ring-red-500">
            <svg class="mr-1 h-5 w-5" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24" stroke="currentColor" stroke-width="2">
                <path stroke-linecap="round" stroke-linejoin="round" d="M6 18L18 6M6 6l12 12" />
            </svg>
            حذف
        </button>
    </form>

</td>
@endif
                   </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>

            <!-- Pagination -->
            <div class="bg-white px-4 py-3 flex items-center justify-between border-t border-gray-200 sm:px-6">
                <div class="flex-1 flex justify-between sm:hidden">
                    <a href="{{ $services->previousPageUrl() }}"
                        class="relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
                        Previous
                    </a>
                    <a href="{{ $services->nextPageUrl() }}"
                        class="ml-3 relative inline-flex items-center px-4 py-2 border border-gray-300 text-sm font-medium rounded-md text-gray-700 bg-white hover:bg-gray-50">
                        Next
                    </a>
                </div>
            </div>
        </div>
    </main>
</div>

@endsection
