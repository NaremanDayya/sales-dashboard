<div style="height: 40px;"></div>
<footer class=" footer py-6 background-color:#f6f9ff;">
        <div class="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
            <div class="flex flex-col md:flex-row justify-center items-center">
                <p class="text-gray-500 text-sm text-center">جميع الحقوق محفوظة &copy; شركة آفاق الخليج 2025</p>
            </div>
        </div>
    </footer>
