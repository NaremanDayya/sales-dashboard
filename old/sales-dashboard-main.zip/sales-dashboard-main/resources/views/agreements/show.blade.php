@extends('layouts.master')
@section('title','Show Agreement')
@section('content')
<div class="container mx-auto px-4 py-8">
    <div class="flex justify-between items-center mb-8">
        <h1 class="text-3xl font-bold text-gray-800">تفاصيل الاتفاقية</h1>
        <div class="flex space-x-4">
            @php
            $canEditDate = Auth::user()->hasActiveEditPermission($agreement,
            $editableField);
            @endphp
            @if($canEditDate)
            <a href="{{ route('salesrep.agreements.edit', [$salesrep, $agreement]) }}"
                class="px-4 py-2 bg-blue-600 text-white rounded-lg hover:bg-blue-700 transition duration-200 flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                    <path
                        d="M13.586 3.586a2 2 0 112.828 2.828l-.793.793-2.828-2.828.793-.793zM11.379 5.793L3 14.172V17h2.828l8.38-8.379-2.83-2.828z" />
                </svg>
                تعديل الإتفاقية
            </a>
            @endif
            <a href="{{ route('salesrep.agreements.index', $salesrep) }}"
                class="px-4 py-2 bg-gray-200 text-gray-700 rounded-lg hover:bg-gray-300 transition duration-200 flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                    <path fill-rule="evenodd"
                        d="M9.707 16.707a1 1 0 01-1.414 0l-6-6a1 1 0 010-1.414l6-6a1 1 0 011.414 1.414L5.414 9H17a1 1 0 110 2H5.414l4.293 4.293a1 1 0 010 1.414z"
                        clip-rule="evenodd" />
                </svg>
                رجوع
            </a>
        </div>
    </div>

    <!-- Main Card -->
    <div class="bg-white rounded-xl shadow-md overflow-hidden mb-8">
        <div class="p-6">
            <div class="flex justify-between items-start">
                <div>
                    @php
                    $status = $agreement->agreement_status;
                    $statusLabels = [
                    'active' => 'سارية',
                    'terminated' => 'تم إيقافها',
                    'expired' => 'منتهية',
                    ];
                    $statusClasses = [
                    'active' => 'bg-green-100 text-green-800',
                    'terminated' => 'bg-red-100 text-red-800',
                    'expired' => 'bg-yellow-100 text-yellow-800',
                    ];
                    @endphp

                    <span
                        class="inline-block px-3 py-1 rounded-full text-sm font-semibold {{ $statusClasses[$status] ?? 'bg-gray-100 text-gray-800' }}">
                        {{ $statusLabels[$status] ?? $status }}
                    </span>

                    <h2 class="mt-2 text-2xl font-bold text-gray-800">إتفاقية رقم {{ $agreement->id }}</h2>
                </div>
                <div class="text-right">
                    <p class="text-sm text-gray-500">تم إنشاؤها بتاريخ {{ $agreement->created_at->format('M d, Y') }}
                    </p>
                    <p class="text-sm text-gray-500">اخر تحديث {{ $agreement->updated_at->diffForHumans() }}</p>
                </div>
            </div>

            <div class="mt-6 grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                <!-- Client Card -->
                <div class="bg-gray-50 p-4 rounded-lg border border-gray-200">
                    <h3 class="text-lg font-semibold text-gray-700 mb-2 flex items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2 text-blue-500" viewBox="0 0 20 20"
                            fill="currentColor">
                            <path fill-rule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z"
                                clip-rule="evenodd" />
                        </svg>
                        معلومات العميل
                    </h3>
                    <div class="space-y-2">
                        <p><span class="font-medium">اسم العميل:</span> {{ $agreement->client->contact_person }}</p>
                        <p><span class="font-medium">الشركة:</span> {{ $agreement->client->company_name ?? 'N/A' }}</p>
                        <a href="{{ $agreement->client->whatsapp_link }}" target="_blank"
                            class="inline-flex items-center px-4 py-2 bg-green-600 text-white text-sm font-semibold rounded-lg shadow hover:bg-green-700 transition">
                            <svg class="w-4 h-4 mr-2 fill-current" viewBox="0 0 32 32"
                                xmlns="http://www.w3.org/2000/svg">
                                <path
                                    d="M16.001 2.999c-7.18 0-13 5.82-13 13 0 2.366.647 4.556 1.771 6.449l-1.834 6.658 6.83-1.792A12.933 12.933 0 0016 29.001c7.18 0 13-5.82 13-13s-5.82-13.002-13-13.002zm0 24.002c-2.103 0-4.066-.55-5.783-1.506l-.412-.238-4.054 1.064 1.083-3.94-.267-.422A10.964 10.964 0 015 15.999c0-6.065 4.936-11 11-11s11 4.935 11 11-4.935 11.002-11 11.002zm6.3-8.504c-.34-.17-2.01-.992-2.32-1.105-.31-.113-.535-.17-.76.17s-.87 1.104-1.067 1.33c-.197.227-.39.255-.73.085-.34-.17-1.44-.53-2.745-1.688-1.015-.907-1.7-2.025-1.9-2.365-.197-.34-.02-.524.148-.693.153-.152.34-.396.51-.595.17-.198.226-.34.34-.567.113-.227.057-.425-.028-.595-.085-.17-.76-1.823-1.04-2.494-.272-.653-.55-.566-.76-.576l-.648-.012c-.226 0-.594.085-.905.425s-1.19 1.162-1.19 2.837c0 1.675 1.22 3.293 1.39 3.52.17.227 2.4 3.662 5.824 5.133 3.424 1.47 3.424.982 4.042.924.62-.057 2.01-.822 2.29-1.616.283-.794.283-1.474.198-1.616-.085-.142-.31-.227-.65-.396z" />
                            </svg>
                            WhatsApp Chat
                        </a>

                        <p><span class="font-medium">رقم الجوال:</span> {{ $agreement->client->phone }}</p>
                    </div>
                </div>

                <!-- Service Card -->
                <div class="bg-gray-50 p-4 rounded-lg border border-gray-200">
                    <h3 class="text-lg font-semibold text-gray-700 mb-2 flex items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2 text-purple-500" viewBox="0 0 20 20"
                            fill="currentColor">
                            <path
                                d="M9 6a3 3 0 11-6 0 3 3 0 016 0zM17 6a3 3 0 11-6 0 3 3 0 016 0zM12.93 17c.046-.327.07-.66.07-1a6.97 6.97 0 00-1.5-4.33A5 5 0 0119 16v1h-6.07zM6 11a5 5 0 015 5v1H1v-1a5 5 0 015-5z" />
                        </svg>
                        تفاصيل الخدمة
                    </h3>
                    <div class="space-y-2">
                        <p><span class="font-medium">الخدمة:</span> {{ $agreement->service->name }}</p>
                        <p><span class="font-medium">الكمية:</span> {{ $agreement->product_quantity }}</p>
                        <p><span class="font-medium">التسعيرة:</span>{{
                            number_format($agreement->price) }}{{ config('app.currency', 'ريال') }}
                        </p>
                        <p><span class="font-medium">السعر الكلي:</span> {{
                            number_format($agreement->total_amount)
                            }}{{ config('app.currency', 'ريال') }}</p>
                    </div>
                </div>

                <!-- Sales Rep Card -->
                <div class="bg-gray-50 p-4 rounded-lg border border-gray-200">
                    <h3 class="text-lg font-semibold text-gray-700 mb-2 flex items-center">
                        <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2 text-green-500" viewBox="0 0 20 20"
                            fill="currentColor">
                            <path fill-rule="evenodd" d="M10 9a3 3 0 100-6 3 3 0 000 6zm-7 9a7 7 0 1114 0H3z"
                                clip-rule="evenodd" />
                        </svg>مندوب العميل
                    </h3>
                    <div class="space-y-2">
                        <p><span class="font-medium">اسم سفير العلامة التجارية:</span> {{ $agreement->salesRep->name }}</p>
                        <p><span class="font-medium">البريد الإلكتروني:</span> {{ $agreement->salesRep->user->email }}
                        </p>
                        <p><span class="font-medium">رقم الجوال:</span> {{
                            $agreement->salesRep->user->contact_info['phone']
                            ?? '-' }}</p>
                    </div>
                </div>
            </div>
        </div>
    </div>

    <!-- Timeline Section -->
    <div class="bg-white rounded-xl shadow-md overflow-hidden mb-8">
        <div class="p-6">
            <h3 class="text-xl font-bold text-gray-800 mb-4 flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 mr-2 text-blue-500" fill="none"
                    viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                </svg>
                التسلسل الزمني للاتفاقية
            </h3>

            <div class="relative">
                <!-- Timeline line -->
                <div class="absolute left-4 top-0 h-full w-0.5 bg-gray-200"></div>

                <!-- Timeline items -->
                <div class="space-y-8">
                    <!-- Signing Date -->
                    <div class="relative pl-12">
                        <div
                            class="absolute left-0 top-0 h-8 w-8 rounded-full bg-blue-500 flex items-center justify-center text-white">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20"
                                fill="currentColor">
                                <path fill-rule="evenodd"
                                    d="M10 18a8 8 0 100-16 8 8 0 000 16zm3.707-9.293a1 1 0 00-1.414-1.414L9 10.586 7.707 9.293a1 1 0 00-1.414 1.414l2 2a1 1 0 001.414 0l4-4z"
                                    clip-rule="evenodd" />
                            </svg>
                        </div>
                        <div class="bg-blue-50 p-4 rounded-lg border border-blue-100">
                            <h4 class="font-semibold text-blue-800">تاريخ التوقيع</h4>
                            <p class="text-gray-600">{{ $agreement->signing_date->format('F j, Y') }}</p>
                        </div>
                    </div>

                    <!-- Implementation Date -->
                    <div class="relative pl-12">
                        <div
                            class="absolute left-0 top-0 h-8 w-8 rounded-full bg-purple-500 flex items-center justify-center text-white">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20"
                                fill="currentColor">
                                <path
                                    d="M10.394 2.08a1 1 0 00-.788 0l-7 3a1 1 0 000 1.84L5.25 8.051a.999.999 0 01.356-.257l4-1.714a1 1 0 11.788 1.838L7.667 9.088l1.94.831a1 1 0 00.787 0l7-3a1 1 0 000-1.838l-7-3z" />
                                <path
                                    d="M3.31 9.397L5 10.12v4.102a8.969 8.969 0 00-1.05-.174 1 1 0 01-.89-.89 11.115 11.115 0 01.25-3.762zM9.3 16.573A9.026 9.026 0 007 14.935v-3.957l1.818.78a3 3 0 002.364 0l5.508-2.361a11.026 11.026 0 01.25 3.762 1 1 0 01-.89.89 8.968 8.968 0 00-5.35 2.524 1 1 0 01-1.4 0zM6 18a1 1 0 001-1v-2.065a8.935 8.935 0 00-2-.712V17a1 1 0 001 1z" />
                            </svg>
                        </div>
                        <div class="bg-purple-50 p-4 rounded-lg border border-purple-100">
                            <h4 class="font-semibold text-purple-800">تاريخ التنفيذ</h4>
                            <p class="text-gray-600">{{ $agreement->implementation_date?->format('F j, Y') }}</p>
                        </div>
                    </div>

                    <!-- End Date -->
                    <div class="relative pl-12">
                        <div class="absolute left-0 top-0 h-8 w-8 rounded-full
                            {{ $agreement->end_date && now()->gt($agreement->end_date) ? 'bg-red-500' : 'bg-yellow-500' }}
                            flex items-center justify-center text-white">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20"
                                fill="currentColor">
                                <path fill-rule="evenodd"
                                    d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z"
                                    clip-rule="evenodd" />
                            </svg>
                        </div>
                        <div class="bg-yellow-50 p-4 rounded-lg border border-yellow-100">
                            <h4 class="font-semibold text-yellow-800">تاريخ انتهاء الإتفاقية</h4>
                            <p class="text-gray-600">
                                {{ $agreement->end_date ? $agreement->end_date->format('F j, Y') : '—' }}
                            </p>
                            <p
                                class="mt-1 text-sm {{ now()->gt($agreement->end_date) ? 'text-red-600' : 'text-yellow-600' }}">
                                {{ now()->gt($agreement->end_date) ? 'الاتفاقية منتهية' : 'تنتهي بعد
                                '.$agreement->end_date->diffForHumans() }}
                            </p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    @if(Auth::user()->role == 'salesRep')
    <div class="bg-white rounded-xl shadow-md overflow-hidden mb-8">
        <div class="p-6">
            <h3 class="text-xl font-bold text-gray-800 mb-4 flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 mr-2 text-blue-500" fill="none"
                    viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M11 5H6a2 2 0 00-2 2v11a2 2 0 002 2h11a2 2 0 002-2v-5m-1.414-9.414a2 2 0 112.828 2.828L11.828 15H9v-2.828l8.586-8.586z" />
                </svg>
                طلبات تعديل الإتفاقية
            </h3>

            <div class="bg-blue-50 border-l-4 border-blue-500 p-4 mb-6 rounded-r-lg">
                <div class="flex">
                    <div class="flex-shrink-0">
                        <svg class="h-5 w-5 text-blue-500" viewBox="0 0 20 20" fill="currentColor">
                            <path fill-rule="evenodd"
                                d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z"
                                clip-rule="evenodd" />
                        </svg>
                    </div>
                    <div class="ml-3">
                        <p class="text-sm text-blue-700">
                            املأ الفورم لإرسال طلب تعديل للإتفاقية وسيتم مراجعته من قبل الإدارة
                        </p>
                    </div>
                </div>
            </div>

            <form method="POST" class="prevent-multi-submit" action="{{ route('agreement-edit-requests.store', $agreement) }}">
                @csrf
                <div class="grid grid-cols-1 md:grid-cols-2 gap-6">
                    <div class="mb-4">
                        <label class="block text-gray-700 text-sm font-medium mb-2">الحقل المطلوب تعديله</label>
                        <select id="edited_field" name="edited_field"
                            class="w-full px-3 py-2 border border-gray-300 rounded-md shadow-sm focus:outline-none focus:ring-blue-500 focus:border-blue-500"
                            required>
                            <option value="" disabled selected>اختر الحقل</option>
                            @foreach($columns as $key => $label)
                            <option value="{{ $key }}">{{ $label }}</option>
                            @endforeach
                        </select>

                        <label for="update_message"
                            class="block mb-2 font-medium text-gray-700 dark:text-gray-300">رسالة التحديث</label>
                        <textarea id="update_message" name="update_message" required rows="4"
                            class="border rounded p-2 mb-4 w-full"
                            placeholder="أضف رسالة حول سبب التغيير...">{{ old('update_message') }}</textarea>
                    </div>
                </div>

                <div class="flex justify-end">
                    <button type="submit"
                        class="px-4 py-2 bg-blue-600 text-white rounded-md hover:bg-blue-700 focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-blue-500 transition-colors duration-200">
                        إرسال طلب تعديل
                    </button>
                </div>
            </form>
        </div>
    </div>
    @endif
    <div class="bg-white rounded-xl shadow-md overflow-hidden mb-8">
        <div class="p-6">
            <h3 class="text-xl font-bold text-gray-800 mb-4 flex items-center">
                <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 mr-2 text-blue-500" fill="none"
                    viewBox="0 0 24 24" stroke="currentColor">
                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                        d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                </svg>
                طلبات التعديل الأخيرة
            </h3>

            <div class="space-y-3 max-h-96 overflow-y-auto pr-2">
                @forelse($agreement->editRequests()->take(3)->latest()->get()  as $request)
                <form method="GET"
                    action="{{ route(
        Auth::user()->role === 'admin' ? 'admin.agreement-request.edit' : 'admin.agreement-request.review',
        ['agreement' => $request->agreement_id, 'agreement_request' => $request->id]
    ) }}">
                    @csrf
                    <button type="submit" class="w-full text-left">
                        <div class="border rounded-lg p-3 bg-gray-50 hover:bg-gray-100 transition cursor-pointer">
                            <div class="flex justify-between items-start">
                                <span class="font-medium text-sm text-gray-700">
طلب تعديل إتفاقية                                </span>
<span
    class="px-2 py-1 rounded-full text-xs font-semibold
        {{ $request->status === 'pending' ? 'bg-yellow-100 text-yellow-800' :
           ($request->status === 'approved' ? 'bg-green-100 text-green-800' : 'bg-red-100 text-red-800') }}">
    {{ $request->status === 'pending' ? 'قيد المراجعة' : ($request->status === 'approved' ? 'تمت الموافقة' : 'مرفوض') }}
</span>
                            </div>
                            <p class="text-sm mt-1 text-gray-600 line-clamp-2">{{ $request->description }}</p>
                            <div class="flex justify-between items-center mt-2">
                                <small class="text-gray-400">
                                    {{ $request->created_at->diffForHumans() }}
                                </small>
                                @if($request->status === 'pending')
                                <span class="animate-pulse text-xs text-yellow-600">
                                    <svg xmlns="http://www.w3.org/2000/svg" class="h-4 w-4 inline" viewBox="0 0 20 20"
                                        fill="currentColor">
                                        <path fill-rule="evenodd"
                                            d="M10 18a8 8 0 100-16 8 8 0 000 16zm1-12a1 1 0 10-2 0v4a1 1 0 00.293.707l2.828 2.829a1 1 0 101.415-1.415L11 9.586V6z"
                                            clip-rule="evenodd" />
                                    </svg>
                                    قيد المراجعة
                                </span>
                                @endif
                            </div>
                        </div>
                    </button>
                </form>
                @empty
                <div class="text-center py-4 text-gray-500">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-8 w-8 mx-auto mb-2" fill="none" viewBox="0 0 24 24"
                        stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M20 13V6a2 2 0 00-2-2H6a2 2 0 00-2 2v7m16 0v5a2 2 0 01-2 2H6a2 2 0 01-2-2v-5m16 0h-2.586a1 1 0 00-.707.293l-2.414 2.414a1 1 0 01-.707.293h-3.172a1 1 0 01-.707-.293l-2.414-2.414A1 1 0 006.586 13H4" />
                    </svg>
                    <p class="text-sm">لا يوجد طلبات تعديل</p>
                </div>
                @endforelse

                @if($agreement->editRequests->count() > 3)
                <div class="text-center mt-4">
                    <a href="{{ route('agreement-request.index', $agreement) }}"
                        class="text-blue-600 hover:text-blue-800 text-sm font-medium">
                        عرض جميع طلبات التعديل
                    </a>
                </div>
                @endif
            </div>
        </div>
    </div>
    <!-- Additional Details Section -->
    <div class="grid grid-cols-1 md:grid-cols-2 gap-6 mb-8">
        <!-- Termination Details -->
        <div class="bg-white rounded-xl shadow-md overflow-hidden">
            <div class="p-6">
                <h3 class="text-xl font-bold text-gray-800 mb-4 flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 mr-2 text-red-500" fill="none"
                        viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M12 9v2m0 4h.01m-6.938 4h13.856c1.54 0 2.502-1.667 1.732-3L13.732 4c-.77-1.333-2.694-1.333-3.464 0L3.34 16c-.77 1.333.192 3 1.732 3z" />
                    </svg>
                    التفاصيل الزمنية
                </h3>
                <div class="space-y-4">
                    <div>
                        <p class="text-sm text-gray-500">نوع انتهاء الإتفاقية</p>
                        @php
                        $terminationType = $agreement->termination_type;
                        $terminationTypeLabels = [
                        'returnable' => 'مشروطة بمقابل',
                        'non_returnable' => 'غير مشروطة بمقابل',
                        ];
                        @endphp

                        <p class="font-medium">{{ $terminationTypeLabels[$terminationType] ?? $terminationType }}</p>
                    </div>

                    <div>
                        <p class="text-sm text-gray-500">فترة الإخطار</p>
                        <p class="font-medium">{{ $agreement->notice_months }} شهر</p>
                    </div>

                    <div>
                        <p class="text-sm text-gray-500">حالة الإخطار</p>
                        @php
                        $noticeStatus = $agreement->notice_status;
                        $noticeStatusLabels = [
                        'sent' => 'تم الإخطار',
                        'not_sent' => 'لم يتم الإخطار',
                        ];
                        @endphp

                        <p class="font-medium">{{ $noticeStatusLabels[$noticeStatus] ?? $noticeStatus }}</p>
                    </div>

                    @if($withinNoticePeriod)
                    <div class="mt-4 p-3 bg-blue-50 rounded-lg border border-blue-200">
                        <p class="text-blue-700 flex items-center">
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5 mr-2" viewBox="0 0 20 20"
                                fill="currentColor">
                                <path fill-rule="evenodd"
                                    d="M18 10a8 8 0 11-16 0 8 8 0 0116 0zm-7-4a1 1 0 11-2 0 1 1 0 012 0zM9 9a1 1 0 000 2v3a1 1 0 001 1h1a1 1 0 100-2v-3a1 1 0 00-1-1H9z"
                                    clip-rule="evenodd" />
                            </svg>
                            الإتفاقيةلا زالت في فترة الإخطار
                        </p>
                    </div>
                    @endif
                </div>
            </div>
        </div>

        <!-- Actions Card -->
        <div class="bg-white rounded-xl shadow-md overflow-hidden">
            <div class="p-6">
                <h3 class="text-xl font-bold text-gray-800 mb-4 flex items-center">
                    <svg xmlns="http://www.w3.org/2000/svg" class="h-6 w-6 mr-2 text-green-500" fill="none"
                        viewBox="0 0 24 24" stroke="currentColor">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M13 10V3L4 14h7v7l9-11h-7z" />
                    </svg>
                    إرسال تاريخ الإخطار
                </h3>

                <div class="space-y-3">
                    @if($agreement->notice_status === 'not_sent' && $withinNoticePeriod)
                    <form class="prevent-multi-submit" action="{{ route('agreements.updateNoticeStatus', [$salesrep, $agreement]) }}" method="POST">
                        @csrf
                        @method('PUT')
                        <input type="hidden" name="notice_status" value="sent">
                        <input type="date" name="notice_date" id="notice_date"
                            value="{{ old('start_date', isset($model) && $model->start_date ? $model->start_date->format('Y-m-d\TH:i') : '') }}"
                            class="form-control" required>

                        <button type="submit"
                            class="w-full flex items-center justify-between px-4 py-3 bg-blue-100 text-blue-700 rounded-lg hover:bg-blue-200 transition duration-200">
                            <span>تم الإخطار للإتفاقية</span>
                            <svg xmlns="http://www.w3.org/2000/svg" class="h-5 w-5" viewBox="0 0 20 20"
                                fill="currentColor">
                                <path d="M2.003 5.884L10 9.882l7.997-3.998A2 2 0 0016 4H4a2 2 0 00-1.997 1.884z" />
                                <path d="M18 8.118l-8 4-8-4V14a2 2 0 002 2h12a2 2 0 002-2V8.118z" />
                            </svg>
                        </button>
                    </form>

                    @else
                    <p style="font-semibold">لقد قمت بإرسال تاريخ الإخطار لهذه الإتفاقية</p>
                    @endif
                </div>
            </div>
        </div>
    </div>
</div>
@endsection
@push('scripts')
<script>
    document.addEventListener('DOMContentLoaded', function () {
        const select = document.getElementById('edited_field');
        const textarea = document.getElementById('update_message');

        select.addEventListener('change', function () {
            const selectedLabel = select.options[select.selectedIndex].text;
            textarea.placeholder = `أضف رسالة حول سبب تغيير ${selectedLabel}...`;
        });
    });
document.querySelectorAll(".prevent-multi-submit").forEach(form => {
    form.addEventListener("submit", function(e) {
        let button = form.querySelector("button[type=submit]");
        button.disabled = true;
    });
});
</script>
@endpush
